import streamlit as st
import pandas as pd
import matplotlib.pyplot as plt
import time
import yfinance as yf
from keras.models import Sequential
from keras.layers import LSTM, Dense
from sklearn.preprocessing import MinMaxScaler
import numpy as np

st.set_page_config(page_title="AI Stock Predictor", layout="wide")

# -------------------------------
# Helper functions
# -------------------------------
@st.cache_data
def fetch_data(ticker, period='60d', interval='15m'):
    data = yf.download(ticker, period=period, interval=interval, progress=False)
    data = data[['Open', 'High', 'Low', 'Close']]
    data.dropna(inplace=True)
    return data

def prepare_data(data):
    scaler = MinMaxScaler(feature_range=(0,1))
    scaled = scaler.fit_transform(data)
    X, y = [], []
    for i in range(60, len(scaled)):
        X.append(scaled[i-60:i])
        y.append(scaled[i, 3])  # Close price
    return np.array(X), np.array(y), scaler

def build_model():
    model = Sequential([
        LSTM(64, return_sequences=True, input_shape=(60, 4)),
        LSTM(32),
        Dense(1)
    ])
    model.compile(optimizer='adam', loss='mse')
    return model

def predict_future(ticker, period='60d', interval='15m'):
    data = fetch_data(ticker, period, interval)
    X, y, scaler = prepare_data(data.values)
    model = build_model()
    model.fit(X, y, epochs=5, batch_size=32, verbose=0)
    pred = model.predict(X[-1].reshape(1, 60, 4))
    predicted_close = scaler.inverse_transform(
        np.concatenate((np.zeros((1, 3)), pred), axis=1)
    )[0, -1]
    return predicted_close, data

# -------------------------------
# Streamlit UI
# -------------------------------
st.title("📈 AI Hybrid Stock Predictor")
st.markdown("#### Predict short-term and long-term trends using AI-powered LSTM models")

ticker = st.text_input("Enter Stock Symbol (e.g., AAPL, RELIANCE.NS):", "RELIANCE.NS")

if st.button("🔮 Predict"):
    with st.spinner("Training models and predicting..."):
        pred, data = predict_future(ticker)
        st.success(f"Predicted next close for {ticker}: **₹{pred:.2f}**")

        st.line_chart(data['Close'], use_container_width=True)
        st.caption("Historical Close Prices (Yahoo Finance)")

# -------------------------------
# Footer note
# -------------------------------
st.markdown("---")
st.caption("⚖️ *For personal research and educational use only. Not financial advice.*")
